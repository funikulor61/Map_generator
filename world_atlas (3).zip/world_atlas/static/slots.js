// ============ «Набор букв» — слот-машина как в vvod.html ============
// Клик по барабану добавляет его символ в поле пароля и запускает
// новый прокрут барабанов. Раскладка букв меняется списком RU/EN.

const LAYOUTS = {
    ru: {
        letters: 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя'.split(''),
        symbols: ['!', '"', '№', ';', '%', ':', '?', '*', '(', ')', '_', '+', '/']
    },
    en: {
        letters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split(''),
        symbols: ['!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '~', '?']
    }
};

// случайные count разных символов из массива
function pickRandom(items, count) {
    const shuffled = [...items].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
}

// один барабан крутится duration миллисекунд и останавливается на символе
function spinReel(reel, pool, finalChar, duration) {
    return new Promise(function (resolve) {
        reel.classList.add("spinning");
        const timer = setInterval(function () {
            reel.textContent = pool[Math.floor(Math.random() * pool.length)];
        }, 50);
        setTimeout(function () {
            clearInterval(timer);
            reel.textContent = finalChar;
            reel.classList.remove("spinning");
            resolve();
        }, duration);
    });
}

// настраиваем одну слот-машину (на странице их может быть несколько)
function setupSlotMachine(machine) {
    const field = document.getElementById(machine.dataset.target);
    const layoutSelect = machine.querySelector(".layout-select");
    const lettersBox = machine.querySelector(".reels-container.letters");
    const symbolsBox = machine.querySelector(".reels-container.symbols");
    const spinBtn = machine.querySelector(".spin-btn");
    const clearBtn = machine.querySelector(".clear-btn");
    let isSpinning = false;

    // создаём барабан: 5 с буквами и 3 с символами
    function makeReel(isSymbol) {
        const reel = document.createElement("div");
        reel.className = "reel" + (isSymbol ? " symbol" : "");
        reel.textContent = "?";
        reel.addEventListener("click", function () {
            if (isSpinning || reel.textContent === "?" || !field) return;
            field.value += reel.textContent;      // символ — в поле пароля
            field.focus();
            reel.style.background = "#5fbf74";    // зелёная вспышка выбора
            setTimeout(function () {
                reel.style.background = "";
                spinAll();                        // и сразу перекручиваем
            }, 150);
        });
        return reel;
    }

    // все 8 барабанов крутятся и останавливаются по очереди
    async function spinAll() {
        if (isSpinning) return;
        isSpinning = true;
        spinBtn.disabled = true;
        const layout = LAYOUTS[layoutSelect.value];
        const letters = pickRandom(layout.letters, 5);
        const symbols = pickRandom(layout.symbols, 3);
        const jobs = [];
        Array.from(lettersBox.children).forEach(function (reel, i) {
            jobs.push(spinReel(reel, layout.letters, letters[i], 400 + i * 150));
        });
        Array.from(symbolsBox.children).forEach(function (reel, i) {
            jobs.push(spinReel(reel, layout.symbols, symbols[i], 550 + i * 200));
        });
        await Promise.all(jobs);
        isSpinning = false;
        spinBtn.disabled = false;
    }

    for (let i = 0; i < 5; i++) lettersBox.appendChild(makeReel(false));
    for (let i = 0; i < 3; i++) symbolsBox.appendChild(makeReel(true));

    spinBtn.addEventListener("click", spinAll);
    clearBtn.addEventListener("click", function () {
        field.value = "";
        field.focus();
    });
    layoutSelect.addEventListener("change", spinAll);
    spinAll();   // первый автоматический прокрут при загрузке страницы
}

// запускаем все слот-машины на странице
document.querySelectorAll(".slot-machine").forEach(setupSlotMachine);
